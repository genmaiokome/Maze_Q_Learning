from Maze_Q_Learning import Agent
import os
import time
import csv
import pprint
import sys
import pygame
import math

if __name__ == "__main__":
    agent = Agent(0.1, 0.1, 0.99)
    agent.maze.initialize()

    imageSize = 50
    SCREEN_WIDTH = 6000
    SCREEN_HEIGHT = 5000

    pygame.init()
    pygame.time.Clock().tick(1000)

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    spaceImg = pygame.image.load("space.jpg")
    batsuImg = pygame.image.load("batsu.jpg")
    blackImg = pygame.image.load("black.jpg")
    humanImg = pygame.image.load("human.jpg")
    goalImg = pygame.image.load("goal.jpg")
    startImg = pygame.image.load("start.jpg")

    episode = 100
    limit = 1500
    sleep_time = 0

    if len(sys.argv) == 2 and sys.argv[1] == "-l":
        with open('./maze_q_data.csv') as r:

            reader = csv.reader(r)
            ary = list(csv.reader(r))
            agent.Q_table = [[float(x) for x in y] for y in ary]
        sleep_time = 0.5
        episode = 1
        agent.rand = 0

    if len(sys.argv) == 3:
        episode = int(sys.argv[1])
        limit = int(sys.argv[2])

    '''with open('./maze_q_data.csv') as r:
        reader = csv.reader(r)
        ary = list(csv.reader(r))
        agent.Q_table = [[float(x) for x in y] for y in ary]
    sleep_time = 0.5
    episode = 1
    agent.rand = 0'''

    map = agent.maze.get_map()

    for k in range(10):
        for l in range(12):
            if map[k][l] == "□":
                screen.blit(blackImg, (10 + (imageSize * l), 10 + (imageSize * k)))
            elif map[k][l] == "S":
                screen.blit(startImg, (10 + (imageSize * l), 10 + (imageSize * k)))
            elif map[k][l] == "×":
                screen.blit(batsuImg, (10 + (imageSize * l), 10 + (imageSize * k)))
            elif map[k][l] == " ":
                screen.blit(spaceImg, (10 + (imageSize * l), 10 + (imageSize * k)))
            elif map[k][l] == "G":
                screen.blit(goalImg, (10 + (imageSize * l), 10 + (imageSize * k)))
            else:
                screen.blit(humanImg, (10 + (imageSize * l), 10 + (imageSize * k)))

    for i in range(episode):
        agent.maze.initialize()

        if i == 300:
            agent.rand = 0

        for j in range(limit):

            pre_position = agent.maze.get_position()

            #print("{}episode, {}step".format(i, j))
            agent.proceed(agent.policy())

            current_position = agent.maze.get_position()

            if(pre_position != current_position):
                px = pre_position % 12
                py = math.floor(pre_position / 12)
                cx = current_position % 12
                cy = math.floor(current_position / 12)
                if agent.maze.maze[pre_position] == "□":
                    screen.blit(blackImg, (10 + (imageSize * px), 10 + (imageSize * py)))
                elif agent.maze.maze[pre_position] == "S":
                    screen.blit(startImg, (10 + (imageSize * px), 10 + (imageSize * py)))
                elif agent.maze.maze[pre_position] == "G":
                    screen.blit(goalImg, (10 + (imageSize * px), 10 + (imageSize * py)))
                elif agent.maze.maze[pre_position] == " ":
                    screen.blit(spaceImg, (10 + (imageSize * px), 10 + (imageSize * py)))
                elif agent.maze.maze[pre_position] == "×":
                    screen.blit(batsuImg, (10 + (imageSize * px), 10 + (imageSize * py)))

                screen.blit(humanImg, (10 + (imageSize * cx), 10 + (imageSize * cy)))

            pygame.display.flip()
            pygame.display.update()

            if agent.maze.is_goal():
                screen.blit(goalImg, (10 + (imageSize * 10), 10 + (imageSize * 8)))
                agent.maze.initialize()
                break

    with open('./maze_q_data.csv', 'w') as w:
        writer = csv.writer(w)
        writer.writerows(agent.Q_table)
