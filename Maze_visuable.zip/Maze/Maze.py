#Maze.py

import time
import random
import os
import math

class Direction():
    UP = -12
    DOWN = + 12
    LEFT = -1
    RIGHT = +1


class Maze:
    def __init__(self):
        self.maze = [
            "□", "□", "□", "□", "□", "□", "□", "□", "□", "□", "□", "□",
            "□", "S", " ", " ", " ", " ", " ", " ", " ", " ", " ", "□",
            "□", "□", " ", "×", " ", "□", "□", "□", "□", "□", "□", "□",
            "□", "□", " ", "×", " ", "□", " ", " ", " ", "×", " ", "□",
            "□", "□", " ", "×", "□", "□", " ", "×", " ", " ", " ", "□",
            "□", "□", " ", "×", "□", "□", " ", "□", "□", "□", " ", "□",
            "□", "□", " ", " ", "□", "□", " ", "□", "□", "□", " ", "□",
            "□", " ", "×", " ", " ", "×", " ", " ", " ", "□", " ", "□",
            "□", " ", " ", " ", " ", " ", " ", " ", " ", "□", "G", "□",
            "□", "□", "□", "□", "□", "□", "□", "□", "□", "□", "□", "□"
        ]
        self.position = 13

    def initialize(self):
        self.position = 13

    def print_map(self):
        for y in range(len(self.maze)):
            if (y + 1) % 12 != 0:
                if y == self.position:
                    print("P", end='')
                else:
                    print(self.maze[y], end='')                    
            else:
                if y == self.position:
                    print("P")
                else:
                    print(self.maze[y])

    # def get_map(self):
    #     map = [[""] * 12] * 10
    #     for i in range(10):
    #         for j in range(12):
    #             map[i][j] = self.maze[i * 12 + j]
    #             if i * 12 + j == self.position:
    #                 map[i][j] = "p"
    #                 print(f'i: {i}, j: {j}')
    #     return map

    def get_map(self):
        map = []
        lst = []
        cnt = 0
        for i in self.maze:
            lst.append(i)
            cnt += 1
            if len(lst) == 12:
                map.append(lst)
                lst = []
        x = self.position % 12
        y = math.floor(self.position / 12)
        map[y][x] = "p"
        return map


    def step(self, direction):
        if direction + self.position>= 0 and \
            direction + self.position <= 120 and \
            self.maze[direction + self.position] != "□":
            self.position = self.position + direction

    
    def is_goal(self):
        if self.maze[self.position] == "G":
            return True
        else:
            return False
        
    def reward(self):
        if self.maze[self.position] == "×":
            return -1
        elif self.maze[self.position] == " " or self.maze[self.position] == "S":
            return -0.5
        else:
            return 0
        
    def get_position(self):
        return self.position
